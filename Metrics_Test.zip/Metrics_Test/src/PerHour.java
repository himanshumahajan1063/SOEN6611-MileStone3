
public class PerHour extends Payment
{
	private int h;

	public PerHour(int a)
	{
		
	}
	
	public String getType()
	{
		return null;
	}

	public void payAdmin()
	{
		
	}

	public void payTech()
	{
			
	}
}

