
public class Employee 

{
private String name;
protected Payment pmnt;

public Employee(String name)
{
	
}
public Employee()
{
	
}
public String getName()
{
	return null;
}

public String getPayType	()
{
	return null;
}

public void calcSalary()
{
	
}

public String getEmpType()
{
	return null;
}

public void setPayment(Payment p)
{
	
}
}
