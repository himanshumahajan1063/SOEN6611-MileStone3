
public class Administrator extends Employee

{
	public Administrator(String s)
	{
		
	}

	public void calcSalary()
	{
		
	}

	public String getEmpType()
	{
		return null;
	}
	
}
