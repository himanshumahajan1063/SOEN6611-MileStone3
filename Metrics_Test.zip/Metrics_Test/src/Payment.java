
public class Payment

{
public String getType()
{
	return null;
}

public void payAdmin()
{
	
}

public void payTech()
{
		
}
}
