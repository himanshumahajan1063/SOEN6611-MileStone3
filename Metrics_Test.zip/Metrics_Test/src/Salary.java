
public class Salary extends Payment

{
private int b;

	public Salary(int a)
	{
		
	}
	
	public String getType()
	{
		return null;
	}

	public void payAdmin()
	{
		
	}

	public void payTech()
	{
			
	}
}
