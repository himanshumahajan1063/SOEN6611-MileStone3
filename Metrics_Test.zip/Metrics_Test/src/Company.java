
public class Company 

{
	
private Employee emp;
public Company()
{
	
}

public void setEmployee(Employee e , int a)
{
	
}

public void printAll()
{
		
}
}
