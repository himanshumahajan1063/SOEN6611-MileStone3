
public class Technical extends Employee

{
public Technical(String s)
{
	
}

public void calcSalary()
{
	
}

public String getEmpType()
{
	return null;
}
}
